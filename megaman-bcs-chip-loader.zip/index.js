import fs from 'fs';
import readline from 'readline';
import propertiesReader from 'properties-reader';
import SerialManager from './SerialManager.js';

const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
const properties = propertiesReader("app.properties");
const serialManager = new SerialManager(properties);

const BCSNaviFile = properties.get("BCSNavi");
const BCSChipsFile = properties.get("BCSChips");

const prompt = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

while(true){
    await askForOption();
}

async function askForOption(){
    return new Promise((resolve, rejects) => {
        prompt.question("(1) Load Navi (2) Unload Navi (3) Save Navi (4) Load Chip (5) Quit: ", async (option) => {
            option = parseInt(option);
    
            switch(option){
                case 1:
                    await serialManager.initialize();
                    let data = await serialManager.syncWriteData("0");
                    serialManager.closeSerialPort();
                    fs.writeFileSync(BCSNaviFile, 'F81F' + data, {encoding: 'hex'});
                    console.log("Navi loaded!");
                    console.log("Creating Navi backup...");
                    fs.writeFileSync("./backup.bin", data, {encoding: 'hex'});
                    console.log("Created Navi backup!")
                    break;
                case 2:
                    fs.writeFileSync(BCSNaviFile, 'FFFF' + 'F'.repeat(2048));
                    console.log("Navi Unloaded!");
                    break;
                case 3:
                    console.error("Saving Navi chip is not supported yet!");
                    // await serialManager.initialize();
                    // let newData = fs.readFileSync(BCSNaviFile, 'utf-8');
                    // newData = newData.substring(5, newData.length);
                    // console.log(newData.length);
                    // for(let i = 0; i < 1024; i++){
                    //     let data = `1:${i} ${newData.substring(i * 2, 2)}`;
                    //     console.log(i);
                    //     if(i == 1023){
                    //         delay(5000)
                    //         await serialManager.syncWriteData(data);
                    //     }else{
                    //         serialManager.writeData(data);
                    //     }
                    // }
                    // serialManager.closeSerialPort();
                    // break;
                case 4:
                    console.error("Loading chip not supported yet!");
                    let chips = await chipPrompt();
                    fs.writeFileSync(BCSChipsFile, chips + "0".repeat(8), {encoding: 'hex'});
                    break;
                case 5:
                    console.log("Thank you for using my application!");
                    process.exit(0);
                default:
                    console.error("No valid option selected!");
            }
            resolve(true);
        });
    });
}



async function chipPrompt(){
    return new Promise(async (resolve, rejects) => {
        let chips = "";
        let pinout = "";
        let promptsDone = 0;

        await serialManager.initialize();

        for(let i = 0; i < 3; i++){
            let currentDone = promptsDone;
            prompt.question(`(1) Load chip ${i} (2) Skip: `, async (option) => {
                option = parseInt(option);
    
                if(option == 1){
                    pinout = await serialManager.syncWriteData("2");
                    let bin = getChipBinValue(pinout).split("").reverse().join("");
                    chips += bin2hex(bin.substr(0, 8));
                    chips += bin2hex(bin.substr(9, 16));
                }else{
                    chips += "0000"
                }
    
                promptsDone++;

                console.log(chips)
            });

            while(promptsDone == currentDone){
                await delay(1000)
            }
        }

        serialManager.closeSerialPort();
        resolve(chips);
    });
}

function getChipBinValue(pinout){
    let bin = pinout.substr(2).slice(0, -1).split("").reverse().join("").padStart(16, '0')
    // let indexId = parseInt(bin, 2) >> 0
    // return indexId.toString().padStart(3, '0');
    return bin;
}

function bin2hex(bin){
    return ("00" + (parseInt(bin, 2)).toString(16)).substr(-2)
}